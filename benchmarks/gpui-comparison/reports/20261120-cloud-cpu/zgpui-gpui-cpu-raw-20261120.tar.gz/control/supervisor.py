#!/usr/bin/env python3
"""Supervise one fixed CPU benchmark build; limits are userspace observations."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path("/workspace/scratch/b7a556b8ef6f")
FIXTURE = ROOT / "zgpui-cloud-source/benchmarks/gpui-comparison"
TOOLS = ROOT / "ssmcp-cloud-tools"
RUN = Path(__file__).resolve().parent
SOURCE = "56d62e47b939f6e3ba355c7868aea7909e53942b"
LOCK_SHA = "23dcd455e3326f9836ea9da927d3014376db6656e56228f55e6421b5ae7ff490"
PATCH_SHA = "961282d90ee7404d1f7a1d9c3d389cb070fbac82e820ad8e4ff72ae7acbe8e07"
GIB = 1024 ** 3
RSS_LIMIT = 4 * GIB
HOST_FLOOR = 3 * GIB
ADMISSION = 7 * GIB + GIB // 4
MAX_SECONDS = 3000
SIGNALLED = False
ACTIVE_CHILD = None

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def atomic(name, value):
    path = RUN / name
    temporary = path.with_name(path.name + ".writing")
    with temporary.open("w") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def capture(arguments, cwd=FIXTURE):
    result = subprocess.run(arguments, cwd=cwd, text=True, capture_output=True, timeout=20)
    if result.returncode:
        raise RuntimeError(result.stderr[-4000:])
    return result.stdout.strip()

def available():
    values = {}
    for line in Path("/proc/meminfo").read_text().splitlines():
        key, value = line.split(":", 1)
        if value.split()[0].isdigit():
            values[key] = int(value.split()[0]) * 1024
    return values["MemAvailable"]

def processes():
    result = []
    for path in Path("/proc").iterdir():
        if not path.name.isdigit():
            continue
        try:
            stat = (path / "stat").read_text()
            fields = stat[stat.rfind(")") + 2:].split()
            status = {}
            for line in (path / "status").read_text().splitlines():
                if ":" in line:
                    key, value = line.split(":", 1)
                    status[key] = value.strip()
            result.append({
                "pid": int(path.name), "ppid": int(fields[1]), "pgid": int(fields[2]),
                "start_ticks": int(fields[19]), "state": fields[0],
                "comm": (path / "comm").read_text().strip(),
                "rss_bytes": int(status.get("VmRSS", "0 kB").split()[0]) * 1024,
            })
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return result

def group_members(pgid):
    return [p for p in processes() if p["pgid"] == pgid and p["state"] != "Z"]

def stop_group(pgid):
    members = group_members(pgid)
    if not members:
        return {"signal": None, "remaining": []}
    # pgid is a child created with start_new_session=True in this same worker.
    if pgid == os.getpgrp():
        raise RuntimeError("refusing to signal the supervisor process group")
    try:
        os.killpg(pgid, signal.SIGTERM)
    except ProcessLookupError:
        return {"signal": "already_exited", "remaining": []}
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        if not group_members(pgid):
            return {"signal": "SIGTERM", "remaining": []}
        time.sleep(0.2)
    if group_members(pgid):
        try:
            os.killpg(pgid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    deadline = time.monotonic() + 3
    while time.monotonic() < deadline and group_members(pgid):
        time.sleep(0.1)
    return {"signal": "SIGKILL", "remaining": group_members(pgid)}

def signal_handler(signum, frame):
    global SIGNALLED
    SIGNALLED = True

def check_fixed_inputs():
    if digest(FIXTURE / ".cache/bin/timing") != "2c17d7c272833c7db68acb5ccf7cd687b55ca247b2fe81d95cca0ff4fc52cf95":
        raise RuntimeError("timing executable changed")
    if digest(FIXTURE / ".cache/bin/allocations") != "a54e314542e08050d4344666f3a02c3ae1a0ab5f9b762f2a24a323bdf9650f83":
        raise RuntimeError("allocation executable changed")
    if 0 not in os.sched_getaffinity(0):
        raise RuntimeError("precommitted CPU 0 is not permitted")
    source_root = FIXTURE.parent.parent
    if capture(["git", "rev-parse", "HEAD"], source_root) != SOURCE:
        raise RuntimeError("unexpected harness commit")
    if capture(["git", "status", "--porcelain"], source_root):
        raise RuntimeError("source worktree is not clean")
    if digest(FIXTURE / "Cargo.lock") != LOCK_SHA:
        raise RuntimeError("CPU lock changed")
    if digest(FIXTURE / "gpui-layout-visibility.patch") != PATCH_SHA:
        raise RuntimeError("visibility patch changed")
    if digest(FIXTURE / ".cache/build-project/Cargo.lock") != LOCK_SHA:
        raise RuntimeError("prepared project lock changed")
    if capture(["git", "rev-parse", "HEAD"], FIXTURE / ".cache/zed") != "a246423a3b24a08e0d0c8574eab3a9de422747e0":
        raise RuntimeError("upstream commit changed")
    profile = __import__("tomllib").loads((FIXTURE / "Cargo.toml").read_text())["profile"]["release"]
    if profile != {"opt-level": 3, "lto": "thin", "codegen-units": 1, "debug": False}:
        raise RuntimeError("release profile changed")
    if capture([str(TOOLS / "rustup-home/toolchains/1.100.0-x86_64-unknown-linux-gnu/bin/rustc"), "--version"]) != "rustc 1.100.0 (0ef1bc386 2026-11-09)":
        raise RuntimeError("unexpected compiler")

def run_stage(name, argv, environment, overall_deadline, stage_timeout=None):
    global ACTIVE_CHILD
    check_fixed_inputs()
    started = time.monotonic()
    deadline = min(overall_deadline, started + stage_timeout) if stage_timeout else overall_deadline
    stdout = RUN / (name + ".stdout")
    stderr = RUN / (name + ".stderr")
    result = {"stage": name, "started_at_utc": now(), "argv": argv,
              "status": "running", "peak_process_group_rss_bytes": 0,
              "minimum_host_mem_available_bytes": available(),
              "resource_limit_kind": "userspace_polling_not_kernel_cgroup",
              "timing_samples_enabled": True}
    with stdout.open("wb") as output, stderr.open("wb") as error:
        process = subprocess.Popen(argv, cwd=FIXTURE, env=environment,
                                   stdout=output, stderr=error, start_new_session=True)
        ACTIVE_CHILD = process
        pgid = process.pid
        atomic("controller.json", {"status": "running", "supervisor_pid": os.getpid(),
               "stage": name, "child_pgid": pgid, "cancel_file": str(RUN / "CANCEL"),
               "source": SOURCE, "started_at_utc": now()})
        print(json.dumps({"stage": name, "event": "started", "pid": process.pid}), flush=True)
        last_report = 0.0
        reason = None
        with (RUN / "resources.ndjson").open("a") as samples:
            while True:
                memory = available()
                members = group_members(pgid)
                rss = sum(p["rss_bytes"] for p in members)
                result["peak_process_group_rss_bytes"] = max(result["peak_process_group_rss_bytes"], rss)
                result["minimum_host_mem_available_bytes"] = min(result["minimum_host_mem_available_bytes"], memory)
                sample = {"at_utc": now(), "stage": name, "host_mem_available_bytes": memory,
                          "group_rss_bytes": rss, "members": members}
                samples.write(json.dumps(sample) + "\n")
                samples.flush()
                if SIGNALLED or (RUN / "CANCEL").exists():
                    reason = "cancel_requested"
                elif memory < HOST_FLOOR:
                    reason = "host_reserve_breached"
                elif rss > RSS_LIMIT:
                    reason = "process_group_rss_limit_breached"
                elif time.monotonic() >= deadline:
                    reason = "deadline_exceeded"
                if reason:
                    result["termination"] = stop_group(pgid)
                    break
                returncode = process.poll()
                if returncode is not None and not members:
                    break
                if time.monotonic() - last_report >= 15:
                    print(json.dumps({"stage": name, "event": "progress",
                          "elapsed_seconds": round(time.monotonic() - started, 1),
                          "group_rss_bytes": rss, "host_mem_available_bytes": memory}), flush=True)
                    last_report = time.monotonic()
                time.sleep(1)
        if process.poll() is None:
            process.wait(timeout=10)
        result["exit_code"] = process.returncode
    result.update(finished_at_utc=now(), wall_seconds=time.monotonic() - started,
                  stdout_sha256=digest(stdout), stderr_sha256=digest(stderr))
    result["status"] = reason or ("passed" if result["exit_code"] == 0 else "command_failed")
    check_fixed_inputs()
    if name == "geometry" and result["status"] == "passed":
        try:
            geometry = json.loads(stdout.read_text())
            result["geometry"] = geometry
            if geometry.get("verified") is not True:
                result["status"] = "geometry_not_verified"
        except (ValueError, OSError) as error:
            result["status"] = "geometry_output_invalid"
            result["parse_error"] = str(error)
    atomic(name + ".json", result)
    ACTIVE_CHILD = None
    print(json.dumps({"stage": name, "event": "exited", "status": result["status"],
                      "exit_code": result["exit_code"], "wall_seconds": result["wall_seconds"],
                      "peak_group_rss_bytes": result["peak_process_group_rss_bytes"]}), flush=True)
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    RUN.mkdir(parents=True, exist_ok=True)
    check_fixed_inputs()
    compilers = [p for p in processes() if p["comm"] in {
        "cargo", "rustc", "clippy-driver", "cc", "gcc", "cc1", "cc1plus",
        "ld", "ld.lld", "lto-wrapper", "lto1"}]
    fresh = {"at_utc": now(), "host_mem_available_bytes": available(),
             "admission_bytes": ADMISSION, "other_compilers": compilers,
             "source": SOURCE, "nice": os.getpriority(os.PRIO_PROCESS, 0),
             "supervisor_sha256": digest(Path(__file__)),
             "kernel_cgroup_claimed": False, "psi_available": Path("/proc/pressure/memory").exists()}
    fresh["admitted"] = fresh["host_mem_available_bytes"] >= ADMISSION and not compilers
    atomic("preflight-only.json" if args.preflight_only else "admission.json", fresh)
    print(json.dumps({"event": "preflight", **fresh}), flush=True)
    if args.preflight_only:
        return 0 if fresh["admitted"] else 2
    lock = (RUN / "ACTIVE.lock").open("a")
    try:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise RuntimeError("another supervisor holds ACTIVE.lock; do not remove it or start a new target")
    if any((RUN / name).exists() for name in ["result.json", "supervisor-error.json", "controller.json"]):
        raise RuntimeError("this run already has a controller or terminal receipt; no automatic retry")
    if not fresh["admitted"] or fresh["nice"] != 19 or (RUN / "CANCEL").exists():
        result = {"status": "not_started", "admission": fresh, "at_utc": now()}
        atomic("result.json", result)
        return 2
    for sig in [signal.SIGTERM, signal.SIGINT]:
        signal.signal(sig, signal_handler)
    environment = os.environ.copy()
    environment.update(CARGO_HOME=str(TOOLS / "cargo-home"), RUSTUP_HOME=str(TOOLS / "rustup-home"),
                       PATH=str(TOOLS / "cargo-home/bin") + os.pathsep + environment["PATH"],
                       CARGO_BUILD_JOBS="1", RUSTFLAGS="", RUSTC_WRAPPER="", RUSTC_WORKSPACE_WRAPPER="",
                       TMPDIR=str(FIXTURE / ".cache/tmp"))
    forbidden = ["CARGO_ENCODED_RUSTFLAGS", "GPUI_LEAK_DETECTION", "ZTRACING", "ZTRACING_WITH_MEMORY",
                 "CARGO_PROFILE_RELEASE_OPT_LEVEL", "CARGO_PROFILE_RELEASE_LTO",
                 "CARGO_PROFILE_RELEASE_CODEGEN_UNITS", "CARGO_BUILD_RUSTFLAGS"]
    if any(environment.get(name) for name in forbidden):
        raise RuntimeError("unexpected inherited benchmark-sensitive compiler environment")
    Path(environment["TMPDIR"]).mkdir(exist_ok=True)
    cargo = str(TOOLS / "cargo-home/bin/cargo")
    deadline = time.monotonic() + MAX_SECONDS - 20
    stages = [
        ("measurement", [sys.executable, str(FIXTURE / "run.py"), "--cpu", "0", "--rounds", "7", "--samples", "5000", "--seed", "20261120", "--nice", "19", "--out", str(RUN / "raw")], None),
    ]
    completed = []
    for name, argv, timeout in stages:
        stage = run_stage(name, argv, environment, deadline, timeout)
        completed.append(stage)
        if stage["status"] != "passed":
            break
    result = {"source": SOURCE, "finished_at_utc": now(), "status":
              "passed" if len(completed) == 1 and all(x["status"] == "passed" for x in completed)
              else completed[-1]["status"], "stages": completed, "timing_samples": "see retained raw records",
              "gpu_runs": 0, "allocation_probe_built": (FIXTURE / ".cache/bin/allocations").is_file()}
    binary = FIXTURE / ".cache/bin/timing"
    if binary.is_file():
        result["timing_binary"] = {"path": str(binary), "bytes": binary.stat().st_size, "sha256": digest(binary)}
    allocation_binary = FIXTURE / ".cache/bin/allocations"
    if allocation_binary.is_file():
        result["allocation_binary"] = {"path": str(allocation_binary), "bytes": allocation_binary.stat().st_size, "sha256": digest(allocation_binary)}
    if result.get("timing_binary", {}).get("sha256") != "2c17d7c272833c7db68acb5ccf7cd687b55ca247b2fe81d95cca0ff4fc52cf95":
        raise RuntimeError("timing executable changed while building the separate allocation probe")
    atomic("result.json", result)
    atomic("controller.json", {"status": "stopped", "supervisor_pid": os.getpid(),
                              "result": "result.json", "at_utc": now(), "source": SOURCE})
    print(json.dumps({"event": "complete", "status": result["status"], "result": str(RUN / "result.json")}), flush=True)
    return 0 if result["status"] == "passed" else 1

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as error:
        RUN.mkdir(parents=True, exist_ok=True)
        termination = None
        if ACTIVE_CHILD is not None:
            termination = stop_group(ACTIVE_CHILD.pid)
            if ACTIVE_CHILD.poll() is None:
                ACTIVE_CHILD.wait(timeout=10)
        atomic("supervisor-error.json", {"at_utc": now(), "type": type(error).__name__, "message": str(error), "termination": termination})
        atomic("controller.json", {"status": "stopped_after_error", "supervisor_pid": os.getpid(), "at_utc": now(), "source": SOURCE})
        print(json.dumps({"event": "supervisor_error", "type": type(error).__name__, "message": str(error)}), flush=True)
        raise
